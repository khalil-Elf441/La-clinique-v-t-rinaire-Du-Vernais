---
title: Lazy Loading Component
description: The lazy component only first loads in its children after they intersect with the viewport
keywords: lazy loading, svelte materialify lazy loading, svelte lazy loading component
related:
  - actions/intersect
  - components/virtual-lists
---

# Lazy

...is coming soon!
