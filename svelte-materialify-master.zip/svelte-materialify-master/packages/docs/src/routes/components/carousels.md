---
title: Carousels
description: The carousel component allows you to cycle through different slides of images and text, either by hand or programmatically.
keywords: carousels, svelte materialify carousel, svelte carousel component
related:
  - components/windows
  - components/slide-groups
---

# Carousels

...are coming soon!
