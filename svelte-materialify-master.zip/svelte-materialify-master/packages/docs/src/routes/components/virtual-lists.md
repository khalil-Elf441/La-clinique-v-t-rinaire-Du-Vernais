---
title: Virtual List Component
description: The virtual list component is able to render a huge list without any loss in performance
keywords: virtual lists, svelte materialify virtual list, svelte virtual list component
related:
  - components/lists
  - components/list-item-groups
  - components/dividers
---

# Virtual Lists

...are coming soon!
