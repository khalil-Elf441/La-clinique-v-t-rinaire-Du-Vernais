export default {
  star: 'https://github.com/TheComputerM/svelte-materialify/stargazers',
  docs: 'https://github.com/TheComputerM/svelte-materialify/tree/master/packages/docs',
};
