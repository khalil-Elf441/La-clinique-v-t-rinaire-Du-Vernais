<div class="grey lighten-1">
  <div class="d-flex flex-wrap align-content-start" style="height: 200px">
    {#each Array(16) as _}
      <div class="white black-text pa-2 ma-1">Flex Item</div>
    {/each}
  </div>
</div>
<br />
<div class="grey lighten-1">
  <div class="d-flex flex-wrap align-content-end" style="height: 200px">
    {#each Array(16) as _}
      <div class="white black-text pa-2 ma-1">Flex Item</div>
    {/each}
  </div>
</div>
<br />
<div class="grey lighten-1">
  <div class="d-flex flex-wrap align-content-center" style="height: 200px">
    {#each Array(16) as _}
      <div class="white black-text pa-2 ma-1">Flex Item</div>
    {/each}
  </div>
</div>
<br />
<div class="grey lighten-1">
  <div class="d-flex flex-wrap align-content-space-between" style="height: 200px">
    {#each Array(16) as _}
      <div class="white black-text pa-2 ma-1">Flex Item</div>
    {/each}
  </div>
</div>
<br />
<div class="grey lighten-1">
  <div class="d-flex flex-wrap align-content-space-around" style="height: 200px">
    {#each Array(16) as _}
      <div class="white black-text pa-2 ma-1">Flex Item</div>
    {/each}
  </div>
</div>
<br />
<div class="grey lighten-1">
  <div class="d-flex flex-wrap align-content-stretch" style="height: 200px">
    {#each Array(16) as _}
      <div class="white black-text pa-2 ma-1">Flex Item</div>
    {/each}
  </div>
</div>
