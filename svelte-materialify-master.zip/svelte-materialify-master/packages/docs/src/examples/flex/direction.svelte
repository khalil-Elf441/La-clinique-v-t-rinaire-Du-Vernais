<div class="grey lighten-1">
  <div class="d-flex flex-row">
    <div class="white black-text pa-2 ma-1">Flex Item 1</div>
    <div class="white black-text pa-2 ma-1">Flex Item 2</div>
    <div class="white black-text pa-2 ma-1">Flex Item 3</div>
  </div>
  <br />
  <div class="d-flex flex-row-reverse">
    <div class="white black-text pa-2 ma-1">Flex Item 1</div>
    <div class="white black-text pa-2 ma-1">Flex Item 2</div>
    <div class="white black-text pa-2 ma-1">Flex Item 3</div>
  </div>
  <br />
  <div class="d-flex flex-column">
    <div class="white black-text pa-2 ma-1">Flex Item 1</div>
    <div class="white black-text pa-2 ma-1">Flex Item 2</div>
    <div class="white black-text pa-2 ma-1">Flex Item 3</div>
  </div>
  <br />
  <div class="d-flex flex-column-reverse">
    <div class="white black-text pa-2 ma-1">Flex Item 1</div>
    <div class="white black-text pa-2 ma-1">Flex Item 2</div>
    <div class="white black-text pa-2 ma-1">Flex Item 3</div>
  </div>
</div>
