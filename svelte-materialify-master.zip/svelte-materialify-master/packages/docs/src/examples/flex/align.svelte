<div class="grey lighten-1">
  <div class="d-flex align-start" style="height: 100px">
    <div class="white black-text pa-2 ma-1">Flex Item 1</div>
    <div class="white black-text pa-2 ma-1">Flex Item 2</div>
    <div class="white black-text pa-2 ma-1">Flex Item 3</div>
  </div>
</div>
<br />
<div class="grey lighten-1">
  <div class="d-flex align-end" style="height: 100px">
    <div class="white black-text pa-2 ma-1">Flex Item 1</div>
    <div class="white black-text pa-2 ma-1">Flex Item 2</div>
    <div class="white black-text pa-2 ma-1">Flex Item 3</div>
  </div>
</div>
<br />
<div class="grey lighten-1">
  <div class="d-flex align-center" style="height: 100px">
    <div class="white black-text pa-2 ma-1">Flex Item 1</div>
    <div class="white black-text pa-2 ma-1">Flex Item 2</div>
    <div class="white black-text pa-2 ma-1">Flex Item 3</div>
  </div>
</div>
<br />
<div class="grey lighten-1">
  <div class="d-flex align-baseline" style="height: 100px">
    <div class="white black-text pa-2 ma-1">Flex Item 1</div>
    <div class="white black-text pa-2 ma-1">Flex Item 2</div>
    <div class="white black-text pa-2 ma-1">Flex Item 3</div>
  </div>
</div>
<br />
<div class="grey lighten-1">
  <div class="d-flex align-stretch" style="height: 100px">
    <div class="white black-text pa-2 ma-1">Flex Item 1</div>
    <div class="white black-text pa-2 ma-1">Flex Item 2</div>
    <div class="white black-text pa-2 ma-1">Flex Item 3</div>
  </div>
</div>
