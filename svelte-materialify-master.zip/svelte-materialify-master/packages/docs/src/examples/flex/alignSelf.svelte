<div class="grey lighten-1">
  <div class="d-flex" style="height: 100px">
    <div class="white black-text pa-2 ma-1 align-self-start">Start</div>
    <div class="white black-text pa-2 ma-1 align-self-end">End</div>
    <div class="white black-text pa-2 ma-1 align-self-center">Center</div>
    <div class="white black-text pa-2 ma-1 align-self-baseline">Baseline</div>
    <div class="white black-text pa-2 ma-1 align-self-auto">Auto</div>
    <div class="white black-text pa-2 ma-1 align-self-stretch">Stretch</div>
  </div>
</div>
