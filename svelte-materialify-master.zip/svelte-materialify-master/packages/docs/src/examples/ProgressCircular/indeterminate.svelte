<script>
  import { ProgressCircular } from 'svelte-materialify/src';
</script>

<div class="d-flex justify-center">
  <ProgressCircular indeterminate color="primary" />
  <div class="pl-2" />
  <ProgressCircular indeterminate color="indigo" />
  <div class="pl-2" />
  <ProgressCircular indeterminate color="success" />
  <div class="pl-2" />
  <ProgressCircular indeterminate color="red" />
  <div class="pl-2" />
  <ProgressCircular indeterminate color="pink" />
</div>
