<div class="d-flex justify-space-between flex-column flex-md-row">
  <div class="rounded-tl-xl blue white-text pa-8 mb-2">.rounded-tl-xl</div>
  <div class="rounded-tr-xl blue white-text pa-8 mb-2">.rounded-tr-xl</div>
  <div class="rounded-bl-xl blue white-text pa-8 mb-2">.rounded-bl-xl</div>
  <div class="rounded-br-xl blue white-text pa-8 mb-2">.rounded-br-xl</div>
</div>
