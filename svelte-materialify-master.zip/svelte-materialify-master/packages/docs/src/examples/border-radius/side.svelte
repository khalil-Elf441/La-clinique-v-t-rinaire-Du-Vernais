<div class="d-flex justify-space-between flex-column flex-md-row">
  <div class="rounded-t-xl blue white-text pa-8 mb-2">.rounded-t-xl</div>
  <div class="rounded-r-xl blue white-text pa-8 mb-2">.rounded-r-xl</div>
  <div class="rounded-b-xl blue white-text pa-8 mb-2">.rounded-b-xl</div>
  <div class="rounded-l-xl blue white-text pa-8 mb-2">.rounded-l-xl</div>
</div>
