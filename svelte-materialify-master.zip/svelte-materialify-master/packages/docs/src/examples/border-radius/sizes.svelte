<div class="d-flex justify-space-around flex-column flex-md-row">
  <div class="rounded-0 blue white-text pa-6 mb-2">.rounded-0</div>
  <div class="rounded-pill blue white-text pa-6 mb-2">.rounded-pill</div>
  <div class="rounded-circle blue white-text pa-6 mb-2">.rounded-circle</div>
</div>
<br />
<div class="d-flex justify-space-between flex-column flex-md-row">
  <div class="rounded-sm blue white-text pa-8 mb-2">.rounded-sm</div>
  <div class="rounded blue white-text pa-8 mb-2">.rounded</div>
  <div class="rounded-lg blue white-text pa-8 mb-2">.rounded-lg</div>
  <div class="rounded-xl blue white-text pa-8 mb-2">.rounded-xl</div>
</div>
