<script>
  import { Textarea } from 'svelte-materialify/src';
</script>

<br />
<Textarea counter="150">150 characters</Textarea>
