<script>
  import { Textarea } from 'svelte-materialify/src';
</script>

<br />
<Textarea autogrow rows={1}>Auto Grow</Textarea>
