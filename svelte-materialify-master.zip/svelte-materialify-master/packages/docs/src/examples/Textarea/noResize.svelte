<script>
  import { Textarea } from 'svelte-materialify/src';
</script>

<Textarea noResize value="You cannot resize this">No Resize</Textarea>
