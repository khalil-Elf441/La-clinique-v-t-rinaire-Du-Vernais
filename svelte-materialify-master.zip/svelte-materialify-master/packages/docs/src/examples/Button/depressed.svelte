<script>
  import { Button } from 'svelte-materialify/src';
</script>

<div class="d-flex flex-column flex-sm-row justify-space-between">
  <Button depressed>Default</Button>
  <Button depressed class="red white-text">Red</Button>
  <Button depressed class="primary-color">Primary</Button>
  <Button depressed disabled>Disabled</Button>
</div>
