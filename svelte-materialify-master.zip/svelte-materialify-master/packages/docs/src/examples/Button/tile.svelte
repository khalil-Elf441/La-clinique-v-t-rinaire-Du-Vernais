<script>
  import { Button, Icon } from 'svelte-materialify/src';
  import { mdiPen } from '@mdi/js';
</script>

<div class="text-center">
  <Button tile class="indigo white-text">
    <Icon path={mdiPen} class="mr-3" />
    Tile
  </Button>
</div>
