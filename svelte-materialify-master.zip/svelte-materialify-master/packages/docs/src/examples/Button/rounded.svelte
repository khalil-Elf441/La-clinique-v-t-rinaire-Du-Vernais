<script>
  import { Button } from 'svelte-materialify/src';
</script>

<Button rounded class="primary-color">Rounded</Button>
