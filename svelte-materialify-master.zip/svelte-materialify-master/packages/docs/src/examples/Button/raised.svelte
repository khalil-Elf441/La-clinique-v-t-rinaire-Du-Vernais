<script>
  import { Button } from 'svelte-materialify/src';
</script>

<div class="d-flex flex-column flex-sm-row justify-space-between">
  <Button>Default</Button>
  <Button class="red white-text">Red</Button>
  <Button class="primary-color">Primary</Button>
  <Button disabled>Disabled</Button>
</div>
