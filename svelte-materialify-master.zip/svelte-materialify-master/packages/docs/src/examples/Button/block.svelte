<script>
  import { Button } from 'svelte-materialify/src';
</script>

<Button block>Block</Button>
