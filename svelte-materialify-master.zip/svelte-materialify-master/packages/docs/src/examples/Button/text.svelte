<script>
  import { Button } from 'svelte-materialify/src';
</script>

<div class="d-flex flex-column flex-sm-row justify-space-between">
  <Button text>Default</Button>
  <Button text class="red-text">Red</Button>
  <Button text class="primary-text">Primary</Button>
  <Button text disabled>Disabled</Button>
</div>
