<script>
  import { Button } from 'svelte-materialify/src';
</script>

<div class="d-flex flex-column flex-sm-row justify-space-between">
  <Button outlined>Default</Button>
  <Button outlined class="red-text">Red</Button>
  <Button outlined class="primary-text">Primary</Button>
  <Button outlined disabled>Disabled</Button>
</div>
