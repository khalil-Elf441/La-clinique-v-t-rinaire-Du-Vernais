<div class="grid-example">
  <slot />
</div>
