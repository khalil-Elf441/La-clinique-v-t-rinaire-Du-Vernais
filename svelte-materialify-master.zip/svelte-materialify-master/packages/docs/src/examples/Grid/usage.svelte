<script>
  import { Container, Row, Col } from 'svelte-materialify/src';
</script>

<Container>
  <Row>
    <Col>One of Three</Col>
    <Col>One of Three</Col>
    <Col>One of Three</Col>
  </Row>
</Container>
