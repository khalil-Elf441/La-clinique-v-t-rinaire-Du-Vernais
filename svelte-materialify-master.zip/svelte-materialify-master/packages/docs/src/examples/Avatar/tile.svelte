<script>
  import { Avatar } from 'svelte-materialify/src';
</script>

<div class="d-flex justify-center">
  <Avatar tile class="blue white-text">TILE</Avatar>
</div>
