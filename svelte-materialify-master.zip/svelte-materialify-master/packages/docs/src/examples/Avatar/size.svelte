<script>
  import { Avatar } from 'svelte-materialify/src';
</script>

<div class="d-flex justify-space-around">
  <Avatar size="36px" class="primary-color">36</Avatar>
  <Avatar class="blue white-text">48</Avatar>
  <Avatar size="62px" class="red white-text">62</Avatar>
</div>
