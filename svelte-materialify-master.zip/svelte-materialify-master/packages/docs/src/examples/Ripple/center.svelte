<script>
  import { Ripple } from 'svelte-materialify/src';
</script>

<div class="text-center pt-8 pb-8 text-h5 elevation-2" use:Ripple={{ centered: true }}>
  HTML element with centered ripple
</div>
