<script>
  import { Tabs, Tab } from 'svelte-materialify/src';
</script>

<Tabs fixedTabs class="primary-color theme--dark">
  <div slot="tabs">
    <Tab>Option</Tab>
    <Tab>Another Selection</Tab>
    <Tab>Some Items</Tab>
    <Tab>Another Selection</Tab>
  </div>
</Tabs>
