<script>
  import { Tabs, Tab } from 'svelte-materialify/src';
</script>

<Tabs grow class="green-text">
  <div slot="tabs">
    <Tab>Item 1</Tab>
    <Tab>Item 2</Tab>
    <Tab>Item 3</Tab>
  </div>
</Tabs>
