<script>
  import { Alert } from 'svelte-materialify/src';
</script>

<Alert class="indigo-text" border="left" coloredBorder>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto, aperiam ad iure
  harum iste ea numquam quo accusamus blanditiis in.
</Alert>
<Alert class="red-text" border="top" coloredBorder>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto, aperiam ad iure
  harum iste ea numquam quo accusamus blanditiis in.
</Alert>
<Alert class="green-text" border="right" coloredBorder>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto, aperiam ad iure
  harum iste ea numquam quo accusamus blanditiis in.
</Alert>
<Alert class="blue-text" border="bottom" coloredBorder>
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto, aperiam ad iure
  harum iste ea numquam quo accusamus blanditiis in.
</Alert>
