<script>
  import { Alert } from 'svelte-materialify/src';
</script>

<Alert class="indigo white-text" border="left">
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto, aperiam ad iure
  harum iste ea numquam quo accusamus blanditiis in.
</Alert>
<Alert class="red white-text" border="top">
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto, aperiam ad iure
  harum iste ea numquam quo accusamus blanditiis in.
</Alert>
<Alert class="green white-text" border="right">
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto, aperiam ad iure
  harum iste ea numquam quo accusamus blanditiis in.
</Alert>
<Alert class="blue white-text" border="bottom">
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto, aperiam ad iure
  harum iste ea numquam quo accusamus blanditiis in.
</Alert>
