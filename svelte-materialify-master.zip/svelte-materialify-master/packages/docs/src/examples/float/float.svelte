<div>
  <div class="float-left">Float left</div>
  <br />
  <div class="float-right">Float right</div>
  <br />
  <div class="float-sm-left">Float left in SM and up</div>
  <br />
  <div class="float-md-right">Float right in MD and up</div>
  <br />
  <div class="float-right float-md-left">Float left in MD and float right in down</div>
  <br />
</div>
