<script>
  import { Subheader } from 'svelte-materialify/src';
</script>

<Subheader>Subheader</Subheader>
