<script>
  import { Switch } from 'svelte-materialify/src';
</script>

<Switch color="red">red</Switch>
<Switch color="blue">blue</Switch>
<br />
<div class="d-flex justify-space-between">
  <Switch color="secondary">secondary</Switch>
  <Switch color="error">error</Switch>
  <Switch color="success">success</Switch>
</div>
