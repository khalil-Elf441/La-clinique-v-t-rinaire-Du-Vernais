<script>
  import { Checkbox } from 'svelte-materialify/src';
</script>

<Checkbox color="red">red</Checkbox>
<Checkbox color="blue">blue</Checkbox>
<br />
<div class="d-flex justify-space-between">
  <Checkbox checked color="secondary">secondary</Checkbox>
  <Checkbox checked color="error">error</Checkbox>
  <Checkbox checked color="success">success</Checkbox>
</div>
