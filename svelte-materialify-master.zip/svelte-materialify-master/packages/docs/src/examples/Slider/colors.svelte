<script>
  import { Slider } from 'svelte-materialify/src';
</script>

<Slider color="red">Red</Slider>
<Slider color="secondary">Secondary</Slider>
<Slider color="green" thumb thumbClass="green" persistentThumb>Green (with thumb)</Slider>
