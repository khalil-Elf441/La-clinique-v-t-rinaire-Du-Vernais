<script>
  import { Slider } from 'svelte-materialify/src';
</script>

<Slider step={10}>Ticks</Slider>
