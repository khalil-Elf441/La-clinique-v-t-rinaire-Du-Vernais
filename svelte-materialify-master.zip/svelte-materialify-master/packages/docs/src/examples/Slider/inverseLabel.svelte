<script>
  import { Slider } from 'svelte-materialify/src';
</script>

<Slider inverseLabel>Inverse Label</Slider>
