<script>
  import { List, ListItem, Divider, Card, Subheader } from 'svelte-materialify/src';
</script>

<Card>
  <List>
    <Subheader>Subheader</Subheader>
    <ListItem>Item 1</ListItem>
    <Divider />
    <ListItem>Item 2</ListItem>
    <Divider />
    <ListItem>Item 3</ListItem>
    <Divider />
    <ListItem>Item 4</ListItem>
  </List>
</Card>
