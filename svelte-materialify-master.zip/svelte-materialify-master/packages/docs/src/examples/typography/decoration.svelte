<div>
  <a href="https://thecomputerm.github.io/" class="text-decoration-none">Non-underlined
    link</a>
  <div class="text-decoration-line-through">Line-through text</div>
  <div class="text-decoration-overline">Overline text</div>
  <div class="text-decoration-underline">Underline text</div>
</div>
