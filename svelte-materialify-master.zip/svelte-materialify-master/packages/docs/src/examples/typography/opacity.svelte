<div>
  <p class="text--primary">Primary Text</p>
  <p class="text--secondary">Secondary Text</p>
  <p class="text--disabled">Disabled Text</p>
</div>
