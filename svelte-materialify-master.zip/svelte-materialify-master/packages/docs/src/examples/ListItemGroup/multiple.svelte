<script>
  import { ListItemGroup, ListItem } from 'svelte-materialify/src';
</script>

<div class="ml-auto mr-auto elevation-2" style="width:500px">
  <ListItemGroup multiple value={[1, 2]}>
    <ListItem>Item 1</ListItem>
    <ListItem>Item 2</ListItem>
    <ListItem>Item 3</ListItem>
    <ListItem>Item 4</ListItem>
  </ListItemGroup>
</div>
