<script>
  import { Footer } from 'svelte-materialify/src';
</script>

<div style="height: 200px;position:relative;">
  <Footer class="justify-center pa-2" absolute>Svelte Materialify is Powerful</Footer>
</div>
