<script>
  import { Footer } from 'svelte-materialify/src';
</script>

<Footer class="justify-center pa-2" padless>Svelte Materialify is Powerful</Footer>
