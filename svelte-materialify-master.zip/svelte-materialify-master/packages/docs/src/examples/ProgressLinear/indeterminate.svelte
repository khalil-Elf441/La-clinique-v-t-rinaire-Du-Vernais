<script>
  import { ProgressLinear } from 'svelte-materialify/src';
</script>

<ProgressLinear indeterminate />
<br />
<ProgressLinear color="blue" backgroundColor="secondary" indeterminate />
<br />
<ProgressLinear color="red" backgroundColor="red" indeterminate />
