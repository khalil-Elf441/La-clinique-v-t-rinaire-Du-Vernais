<script>
  import { ProgressLinear } from 'svelte-materialify/src';
</script>

<ProgressLinear striped value={25} />
<br />
<ProgressLinear striped value={30} buffer={69} />
