<script>
  import { ProgressLinear } from 'svelte-materialify/src';
</script>

<ProgressLinear height="16px" value={25}>25%</ProgressLinear>
