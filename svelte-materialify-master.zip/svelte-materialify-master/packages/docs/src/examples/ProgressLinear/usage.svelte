<script>
  import { ProgressLinear } from 'svelte-materialify/src';
</script>

<ProgressLinear value={25} />
