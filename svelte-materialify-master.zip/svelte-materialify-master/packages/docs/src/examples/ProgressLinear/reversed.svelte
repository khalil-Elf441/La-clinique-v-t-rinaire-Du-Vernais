<script>
  import { ProgressLinear } from 'svelte-materialify/src';
</script>

<ProgressLinear reversed value={25} />
<br />
<ProgressLinear reversed indeterminate />
