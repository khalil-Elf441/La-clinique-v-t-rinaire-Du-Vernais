<script>
  import { Card, CardText, CardActions, Button } from 'svelte-materialify/src';
</script>

<div class="d-flex justify-center mt-4 mb-4">
  <Card style="max-width:300px;">
    <CardText>
      <div>Word of the Day</div>
      <div class="text--primary text-h4">be•nev•o•lent</div>
      <div class="text--primary">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit, qui
        quaerat rerum incidunt nisi ducimus?
      </div>
    </CardText>
    <CardActions>
      <Button text class="primary-text">Learn More</Button>
    </CardActions>
  </Card>
</div>
