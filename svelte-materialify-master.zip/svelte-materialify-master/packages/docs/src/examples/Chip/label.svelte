<script>
  import { Chip } from 'svelte-materialify/src';
</script>

<div class="d-flex justify-center">
  <Chip label class="ma-2">Default</Chip>
  <Chip label class="ma-2 primary-color">Primary</Chip>
  <Chip label class="ma-2 secondary-color">Secondary</Chip>
  <Chip label class="ma-2 red white-text">Red</Chip>
  <Chip label class="ma-2 green white-text">Green</Chip>
</div>
