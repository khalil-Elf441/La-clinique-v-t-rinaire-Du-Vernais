<script>
  import { Chip } from 'svelte-materialify/src';
</script>

<div class="d-flex justify-center align-center">
  <Chip class="ma-2" size="x-small">x-small</Chip>
  <Chip class="ma-2" size="small">small</Chip>
  <Chip class="ma-2">default</Chip>
  <Chip class="ma-2" size="large">large</Chip>
  <Chip class="ma-2" size="x-large">x-large</Chip>
</div>
