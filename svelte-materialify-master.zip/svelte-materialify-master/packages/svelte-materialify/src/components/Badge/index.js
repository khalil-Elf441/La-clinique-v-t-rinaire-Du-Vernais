export { default } from './Badge.svelte';
