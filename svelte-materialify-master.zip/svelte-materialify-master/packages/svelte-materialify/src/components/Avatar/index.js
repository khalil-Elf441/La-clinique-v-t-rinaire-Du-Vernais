export { default } from './Avatar.svelte';
